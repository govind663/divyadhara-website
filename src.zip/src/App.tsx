import {
  useEffect,
  type ReactNode,
} from "react";

import {
  BrowserRouter,
  Navigate,
  Route,
  Routes,
  useLocation,
} from "react-router-dom";

import Layout from "./components/Layout";

import {
  AppProvider,
  useApp,
} from "./context/AppContext";

/* ============================================================================
 * PUBLIC / MAIN PAGES
 * ========================================================================== */

import Home from "./pages/Home";

import Temples from "./pages/Temples";
import TempleDetail from "./pages/TempleDetail";

import Services from "./pages/Services";
import ServiceDetail from "./pages/ServiceDetail";

import Pandits from "./pages/Pandits";
import PanditDetail from "./pages/PanditDetail";

import AshramList, {
  AshramDetail,
} from "./pages/Ashrams";

import {
  CourseList,
  CourseDetail,
} from "./pages/Courses";

import {
  Places,
  Packages,
  PlaceDetail,
  PackageDetail,
  PackageEnquiry,
} from "./pages/Yatra";

import {
  EventList,
  EventDetail,
} from "./pages/Events";

import { PanchangPage } from "./pages/Panchang";

import {
  Gallery,
  Videos,
  Articles,
  ArticleDetail,
} from "./pages/Media";

import {
  About,
  Contact,
} from "./pages/Info";

/* ============================================================================
 * AUTH
 * ========================================================================== */

import {
  Login,
  Register,
  Forgot,
} from "./pages/Auth";

/* ============================================================================
 * ACCOUNT
 * ========================================================================== */

import Dashboard from "./pages/Dashboard";

/* ============================================================================
 * PANDIT
 * ========================================================================== */

import PanditDashboard from "./pages/PanditDashboard";

/* ============================================================================
 * ADMIN
 * ========================================================================== */

import AdminDashboard from "./pages/AdminDashboard";

/* ============================================================================
 * FALLBACK
 * ========================================================================== */

import NotFound from "./pages/NotFound";

/* ============================================================================
 * SUPPORTED ROLES
 * ========================================================================== */

type SupportedRole =
  | "visitor"
  | "pandit"
  | "temple_manager"
  | "sales"
  | "super_admin";

/* ============================================================================
 * ROLE HELPERS
 * ========================================================================== */

function isSupportedRole(
  role: unknown,
): role is SupportedRole {
  return (
    role === "visitor" ||
    role === "pandit" ||
    role === "temple_manager" ||
    role === "sales" ||
    role === "super_admin"
  );
}

/* ============================================================================
 * SCROLL TO TOP
 * ========================================================================== */

function ScrollToTop() {
  const {
    pathname,
    search,
  } = useLocation();

  useEffect(() => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: "auto",
    });
  }, [
    pathname,
    search,
  ]);

  return null;
}

/* ============================================================================
 * AUTH / ROLE GUARD
 * ========================================================================== */

type RequireRoleProps = {
  roles: SupportedRole[];
  children: ReactNode;
};

function RequireRole({
  roles,
  children,
}: RequireRoleProps) {
  const {
    user,
    isLoading,
  } = useApp();

  /* --------------------------------------------------------------------------
   * SESSION LOADING
   * ------------------------------------------------------------------------ */

  if (isLoading) {
    return (
      <div className="grid min-h-screen place-items-center bg-[#fdfaf5] px-5">
        <div className="text-center">
          <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-orange-100">
            <div className="h-5 w-5 animate-spin rounded-full border-2 border-orange-300 border-t-orange-700" />
          </div>

          <h1 className="mt-4 font-display text-xl font-semibold text-[#2a1a10]">
            Verifying session
          </h1>

          <p className="mt-1 text-sm text-stone-500">
            Please wait while
            DivyaDhara verifies your
            account.
          </p>
        </div>
      </div>
    );
  }

  /* --------------------------------------------------------------------------
   * NOT LOGGED IN
   * ------------------------------------------------------------------------ */

  if (!user) {
    return (
      <Navigate
        to="/login"
        replace
      />
    );
  }

  /* --------------------------------------------------------------------------
   * INVALID ROLE
   * ------------------------------------------------------------------------ */

  if (!isSupportedRole(user.role)) {
    return (
      <Navigate
        to="/"
        replace
      />
    );
  }

  /* --------------------------------------------------------------------------
   * WRONG ROLE
   * ------------------------------------------------------------------------ */

  if (!roles.includes(user.role)) {
    return (
      <Navigate
        to="/"
        replace
      />
    );
  }

  /* --------------------------------------------------------------------------
   * AUTHORIZED
   * ------------------------------------------------------------------------ */

  return <>{children}</>;
}

/* ============================================================================
 * APP ROUTES
 * ========================================================================== */

function AppRoutes() {
  return (
    <>
      <ScrollToTop />

      <Routes>
        {/* ====================================================================
         * PUBLIC WEBSITE
         * ================================================================== */}

        <Route element={<Layout />}>
          {/* ------------------------------------------------------------------
           * HOME
           * ---------------------------------------------------------------- */}

          <Route
            index
            element={<Home />}
          />

          {/* ------------------------------------------------------------------
           * DHARMA — TEMPLES
           * ---------------------------------------------------------------- */}

          <Route
            path="temples"
            element={<Temples />}
          />

          <Route
            path="temples/:slug"
            element={<TempleDetail />}
          />

          <Route
            path="temple/:slug"
            element={
              <Navigate
                to="/temples"
                replace
              />
            }
          />

          {/* ------------------------------------------------------------------
           * DHARMA — PUJA SERVICES
           * ---------------------------------------------------------------- */}

          <Route
            path="services"
            element={<Services />}
          />

          <Route
            path="services/:slug"
            element={<ServiceDetail />}
          />

          <Route
            path="puja-services"
            element={
              <Navigate
                to="/services"
                replace
              />
            }
          />

          {/* ------------------------------------------------------------------
           * DHARMA — PANDITS
           * ---------------------------------------------------------------- */}

          <Route
            path="pandits"
            element={<Pandits />}
          />

          <Route
            path="pandits/:slug"
            element={<PanditDetail />}
          />

          {/* ------------------------------------------------------------------
           * PUBLIC LEGACY PANDIT PROFILE
           *
           * IMPORTANT:
           * /pandit/dashboard has its own exact protected route below.
           * React Router ranks the static protected route above this dynamic
           * :slug route, so "dashboard" will NOT be treated as a slug.
           * ---------------------------------------------------------------- */}

          <Route
            path="pandit/:slug"
            element={
              <Navigate
                to="/pandits"
                replace
              />
            }
          />

          {/* ------------------------------------------------------------------
           * ASHRAMS
           * ---------------------------------------------------------------- */}

          <Route
            path="ashrams"
            element={<AshramList />}
          />

          <Route
            path="ashrams/:slug"
            element={<AshramDetail />}
          />

          {/* ------------------------------------------------------------------
           * COURSES
           * ---------------------------------------------------------------- */}

          <Route
            path="courses"
            element={<CourseList />}
          />

          <Route
            path="courses/:slug"
            element={<CourseDetail />}
          />

          {/* ------------------------------------------------------------------
           * PANCHANG
           * ---------------------------------------------------------------- */}

          <Route
            path="panchang"
            element={<PanchangPage />}
          />

          <Route
            path="calendar"
            element={<PanchangPage />}
          />

          <Route
            path="rashifal"
            element={<PanchangPage />}
          />

          <Route
            path="kundli"
            element={<PanchangPage />}
          />

          <Route
            path="gochar"
            element={<PanchangPage />}
          />

          {/* ------------------------------------------------------------------
           * ASTROLOGY ALIASES
           * ---------------------------------------------------------------- */}

          <Route
            path="jyotish"
            element={
              <Navigate
                to="/kundli"
                replace
              />
            }
          />

          <Route
            path="horoscope"
            element={
              <Navigate
                to="/rashifal"
                replace
              />
            }
          />

          {/* ------------------------------------------------------------------
           * EVENTS
           * ---------------------------------------------------------------- */}

          <Route
            path="events"
            element={<EventList />}
          />

          <Route
            path="events/:slug"
            element={<EventDetail />}
          />

          {/* ------------------------------------------------------------------
           * SPIRITUAL PLACES
           * ---------------------------------------------------------------- */}

          <Route
            path="spiritual-places"
            element={<Places />}
          />

          <Route
            path="spiritual-places/:slug"
            element={<PlaceDetail />}
          />

          <Route
            path="places"
            element={
              <Navigate
                to="/spiritual-places"
                replace
              />
            }
          />

          {/* ------------------------------------------------------------------
           * YATRA PACKAGES
           * ---------------------------------------------------------------- */}

          <Route
            path="packages"
            element={<Packages />}
          />

          <Route
            path="packages/:slug"
            element={<PackageDetail />}
          />

          <Route
            path="packages/:slug/enquiry"
            element={<PackageEnquiry />}
          />

          <Route
            path="yatra-packages"
            element={
              <Navigate
                to="/packages"
                replace
              />
            }
          />

          {/* ------------------------------------------------------------------
           * MEDIA
           * ---------------------------------------------------------------- */}

          <Route
            path="gallery"
            element={<Gallery />}
          />

          <Route
            path="videos"
            element={<Videos />}
          />

          <Route
            path="articles"
            element={<Articles />}
          />

          <Route
            path="articles/:slug"
            element={<ArticleDetail />}
          />

          {/* ------------------------------------------------------------------
           * INFORMATION
           * ---------------------------------------------------------------- */}

          <Route
            path="about"
            element={<About />}
          />

          <Route
            path="contact"
            element={<Contact />}
          />

          {/* ------------------------------------------------------------------
           * AUTHENTICATION
           * ---------------------------------------------------------------- */}

          <Route
            path="login"
            element={<Login />}
          />

          <Route
            path="register"
            element={<Register />}
          />

          <Route
            path="forgot-password"
            element={<Forgot />}
          />

          {/* ------------------------------------------------------------------
           * VISITOR DASHBOARD
           * ---------------------------------------------------------------- */}

          <Route
            path="dashboard"
            element={<Dashboard />}
          />
        </Route>

        {/* ====================================================================
         * PANDIT DASHBOARD
         *
         * THIS IS THE IMPORTANT FIX
         * ================================================================== */}

        <Route
          path="pandit/dashboard"
          element={
            <RequireRole
              roles={[
                "pandit",
              ]}
            >
              <PanditDashboard />
            </RequireRole>
          }
        />

        {/* ====================================================================
         * SUPER ADMIN
         * ================================================================== */}

        <Route
          path="admin/dashboard"
          element={
            <RequireRole
              roles={[
                "super_admin",
              ]}
            >
              <AdminDashboard />
            </RequireRole>
          }
        />

        <Route
          path="admin"
          element={
            <Navigate
              to="/admin/dashboard"
              replace
            />
          }
        />

        {/* ====================================================================
         * TEMPLE MANAGER
         * ================================================================== */}

        <Route
          path="temple-manager/dashboard"
          element={
            <RequireRole
              roles={[
                "temple_manager",
              ]}
            >
              <div className="grid min-h-screen place-items-center bg-[#fdfaf5] px-5">
                <div className="rounded-3xl border border-orange-900/10 bg-white p-8 text-center shadow-xl">
                  <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-orange-100 text-orange-700">
                    <span className="text-2xl">
                      ॐ
                    </span>
                  </div>

                  <h1 className="mt-5 text-2xl font-bold text-[#2a1a10]">
                    Temple Manager Dashboard
                  </h1>

                  <p className="mt-2 text-sm text-stone-500">
                    Temple Manager module is
                    being prepared.
                  </p>
                </div>
              </div>
            </RequireRole>
          }
        />

        {/* ====================================================================
         * SALES
         * ================================================================== */}

        <Route
          path="sales/dashboard"
          element={
            <RequireRole
              roles={[
                "sales",
              ]}
            >
              <div className="grid min-h-screen place-items-center bg-[#fdfaf5] px-5">
                <div className="rounded-3xl border border-orange-900/10 bg-white p-8 text-center shadow-xl">
                  <div className="mx-auto grid h-16 w-16 place-items-center rounded-2xl bg-orange-100 text-orange-700">
                    <span className="text-2xl">
                      ॐ
                    </span>
                  </div>

                  <h1 className="mt-5 text-2xl font-bold text-[#2a1a10]">
                    Sales Dashboard
                  </h1>

                  <p className="mt-2 text-sm text-stone-500">
                    Sales module is being
                    prepared.
                  </p>
                </div>
              </div>
            </RequireRole>
          }
        />

        {/* ====================================================================
         * 404
         * ================================================================== */}

        <Route
          path="*"
          element={<NotFound />}
        />
      </Routes>
    </>
  );
}

/* ============================================================================
 * APP ROOT
 * ========================================================================== */

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <AppRoutes />
      </AppProvider>
    </BrowserRouter>
  );
}